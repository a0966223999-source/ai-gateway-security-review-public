import type { Engine } from '../../core/index.ts'
import type { Store } from '../store.ts'
import type { PassesHost } from '../passes.ts'
import type { SourceContextDeps } from '../source-context.ts'
import type { SourceContext } from '../../sources/host.ts'

/** Trusted host capability. Never deserialize this from Config, a Source message, or JSON. */
export interface RecoveryColdIdleCapability {
  readonly binding: Readonly<{
    parentRef: string; parentVersion: string; taskRef: string; version: string; operationKey: string; owner: string
  }>
  readonly ticketId: string
  readonly assignmentId: string
  readonly recipient: string
  readonly reportEvidenceRef: string
  readCurrentSource(): unknown
  readCompletion(context: unknown): unknown
}
export interface RecoveryStatus {
  readonly queryOnly: true
  readonly retryAuthorized: false
  readonly observation: 'unavailable' | 'last_observed_snapshot'
  readonly record?: unknown
}
export function createRecoveryPassEngine(options: {
  engine: Engine
  repo: Store
  coldIdle?: RecoveryColdIdleCapability | undefined
  closing(): boolean
  configured(): boolean
  evaluateDue?: (() => void) | undefined
}): Readonly<{ engine: PassesHost['engine']; recoveryStatus(): RecoveryStatus }>
export function createSourceRecoveryController(options: {
  host: Omit<PassesHost, 'engine'> & { engine: Engine }
  sourceDeps: SourceContextDeps & { store: Store }
  kind: { kind: string; health: readonly string[] }
  coldIdle?: RecoveryColdIdleCapability | undefined
}): Readonly<{
  source: SourceContext
  request(): void
  idle(): Promise<void>
  stop(): Promise<unknown>
  recoveryStatus(): RecoveryStatus
}>
