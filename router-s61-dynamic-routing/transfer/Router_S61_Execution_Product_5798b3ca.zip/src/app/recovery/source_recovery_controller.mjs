import { Passes } from '../passes.ts'
import { sourceContextOf } from '../source-context.ts'
import { bindColdIdle } from './cold_idle.mjs'

// Trusted constructor injection into the EXISTING Passes. Preserve the runtime's full callback,
// including its eval health update. No timer, source registration, or lifecycle replacement.
export function createRecoveryPassEngine({engine,repo,coldIdle,closing,configured,evaluateDue:onEvaluateDue}) {
  let lastRecovery
  // Unlike PassesHost.engine's narrow Pick, this trusted host must supply the same full Engine.
  if(coldIdle!==undefined&&['turnEnded','report'].some(k=>typeof engine[k]!=='function'))throw Error('FULL_ENGINE_REQUIRED')
  const receive=engine.receive.bind(engine),evaluateDue=onEvaluateDue??engine.evaluateDue.bind(engine)
  const originalIdle=coldIdle===undefined?undefined:engine.turnEnded.bind(engine)
  const recoveryEngine=coldIdle===undefined?undefined:{
    report:engine.report.bind(engine),
    turnEnded(...args){
      if(closing()||!configured()||closing())throw Error('RECOVERY_ADMISSION_CLOSED')
      return originalIdle(...args)
    },
  }
  const recovery=coldIdle===undefined?undefined:bindColdIdle({...coldIdle,repo,getEngine:()=>recoveryEngine})
  const passEngine={
    receive,evaluateDue(){
      evaluateDue()
      if(!recovery||closing()||!configured())return
      lastRecovery=recovery.queryOnly()
      if(lastRecovery.record.state!=='not_recorded')return
      // An intent may commit or fail without a fresh observation. Never retain not_recorded.
      lastRecovery=undefined
      const permit=recovery.reserve()
      if(closing()||!configured())return // committed unknown remains query-only after loss of admission
      lastRecovery=recovery.adopt(permit)
    },
  }
  const recoveryStatus=()=>lastRecovery===undefined
    ?{queryOnly:true,retryAuthorized:false,observation:'unavailable'}
    :{...structuredClone(lastRecovery),observation:'last_observed_snapshot'}
  return Object.freeze({engine:Object.freeze(passEngine),recoveryStatus})
}

// Single-kind fixture/owned controller convenience; not a replacement for Runtime's global Passes.
export function createSourceRecoveryController({host,sourceDeps,kind,coldIdle}) {
  let stopped=false
  const closing=()=>stopped||host.closing()
  const configured=()=>host.configured()&&sourceDeps.configured()
  const recoveryPass=createRecoveryPassEngine({engine:host.engine,repo:sourceDeps.store,coldIdle,closing,configured})
  const passes=new Passes({engine:recoveryPass.engine,
    effects:host.effects,health:host.health,lifetime:host.lifetime,configured,closing,
  })
  const deps=Object.create(sourceDeps)
  Object.defineProperties(deps,{
    configured:{value:configured},
    receive:{value(trigger){
      if(closing())throw Error('Orchestrator is stopping')
      return passes.receive(trigger)
    }},
  })
  const source=sourceContextOf(deps,kind)
  return Object.freeze({source,
    request(){if(!closing()&&configured())passes.request()},
    idle:()=>passes.idle(),
    stop(){stopped=true;return passes.stop()},
    recoveryStatus:recoveryPass.recoveryStatus,
  })
}
